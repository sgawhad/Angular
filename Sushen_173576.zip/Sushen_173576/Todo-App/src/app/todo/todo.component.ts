import { Component, OnInit } from '@angular/core';
import { ToDoModel } from '../model/todo';
import { Router } from '@angular/router';
import { TodoService } from '../service/todo.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  todoArr: ToDoModel[];
  isAdding: boolean;
  todo: ToDoModel;

  constructor(private todoService: TodoService) {
    this.todoArr = [];
    this.todo = new ToDoModel();
  }
  addTask() {
    this.todoService.addtask(this.todo);
    this.isAdding = true;

  }
  ngOnInit() {
    this.todoService.getTask();
  }



}
