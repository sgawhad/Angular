import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToDoModel } from '../model/todo';

@Injectable({
  providedIn: 'root'
})
export class TodoService {//service class provides services 


  todo: ToDoModel;
  todoArr: ToDoModel[];

  constructor(private routes: Router) {
    this.todoArr = [];
  }

  login(todo: ToDoModel) {

    this.routes.navigate(['/todo']) //navigate to login page

  }
  gotoHome() {
    this.routes.navigate(['/home']);
  }

  addtask(todo: ToDoModel) {
    this.routes.navigate(['/addnewtask']);

  }

  getTask() {
    this.todoArr.push(this.todo);
    this.routes.navigate(['/todo'])

  }
}
