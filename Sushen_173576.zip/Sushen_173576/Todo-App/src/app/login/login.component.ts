import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TodoService } from '../service/todo.service';
import { ToDoModel } from '../model/todo';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @Input() todo: ToDoModel;

  @Input() valid: boolean;

  @Output() edited = new EventEmitter();

  constructor(private todoService: TodoService) {
    this.todo = new ToDoModel;
  }

  login() { //is called when login button is clicked

    this.valid = true;
    this.todoService.login(this.todo);


  }
  gotoHome() { //is called when home button is pressed
    this.todoService.gotoHome;
  }

  ngOnInit() {
  }

}
