// Class is required to add and delete tasks
export class ToDoModel {
    public todoName: String;
    public todoStatus: String = "incomplete";

}