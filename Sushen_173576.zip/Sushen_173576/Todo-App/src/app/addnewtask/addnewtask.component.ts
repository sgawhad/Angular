import { Component, OnInit } from '@angular/core';
import { ToDoModel } from '../model/todo';
import { TodoService } from '../service/todo.service';

@Component({
  selector: 'app-addnewtask',
  templateUrl: './addnewtask.component.html',
  styleUrls: ['./addnewtask.component.css']
})
export class AddnewtaskComponent implements OnInit {

  todo = new ToDoModel;
  todoService : TodoService;
  constructor() { }

  ngOnInit() {
  }

  addtask(){
    this.todoService.getTask(); //method is called when add new task is clicked
  }

}
