import { Component, OnInit } from '@angular/core';
import { TaskModel } from '../model/task-model';
import { ActivatedRoute, Router } from '@angular/router';
import {filter} from 'rxjs/operators';
import { TaskService } from '../services/task.service';
@Component({
  selector: 'app-updatetask',
  templateUrl: './updatetask.component.html',
  styleUrls: ['./updatetask.component.css']
})
export class UpdatetaskComponent implements OnInit {
  updatedTask: TaskModel;
  paramIndex;
  constructor(private route: ActivatedRoute, private router: Router, private taskService: TaskService) {
    this.updatedTask = new TaskModel();
  }

  ngOnInit() {
    if (window.location.search !== '') {
      // take id from route query param and prefill data of particular task
      this.route.queryParams.pipe(
      filter(params => params.id))
      .subscribe(params => {
      console.log(params.id);
      this.paramIndex = params.id;
      this.updatedTask = this.taskService.getDetailsOf(this.paramIndex);
      });
    }
  }
  updateTask() {
    // send index of task and updated details
    this.taskService.edit(this.paramIndex, this.updatedTask);
  }
}
