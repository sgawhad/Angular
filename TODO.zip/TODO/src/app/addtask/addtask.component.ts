import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskService } from '../services/task.service';
import { TaskModel } from '../model/task-model';

@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent implements OnInit {

  newTask: TaskModel;
  constructor(private router: Router, private taskService: TaskService) {
      this.newTask = new TaskModel();
      // status is set to default incomplete
      this.newTask.taskStatus = 'Incompelte';
   }

  ngOnInit() {
  }
  goBack() {
    this.router.navigate(['/todo']);
  }
  addTask() {
    this.taskService.add(this.newTask);
  }
}
