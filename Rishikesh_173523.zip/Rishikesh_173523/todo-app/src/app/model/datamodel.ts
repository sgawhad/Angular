export class datamodel {
    taskname: any;
    taskstatus: any;
    
}