import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email: string;
  password:string;
  submitted: boolean;

  constructor(private routes:Router) { 

     }

  ngOnInit() {
  }

  validate(){
    this.email="admin@gmail.com";
    if(this.password="123456"){
    this.submitted= true;
    this.routes.navigate(['/todo']);
    }
    else{
      this.routes.navigate(['/login']);
    }
  }

  gotohome()
{
  this.routes.navigate(['/home']);
}
}
