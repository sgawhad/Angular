import { Injectable } from '@angular/core';
import { datamodel } from '../model/datamodel';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  dataarr: datamodel[];

  constructor(private routes: Router) {
    this.dataarr = [];
  }

//Adding data to display component
  add(data: datamodel) {

    this.dataarr.push(data);
    this.routes.navigate(['/display']);
  }
//retreiving data from array
  getData() {
    return this.dataarr;

  }
//deleteing data from rray
  delete(index: number) {
    this.dataarr.splice(index, 1);
  }
//editing data in display component
  edit(id: any) {
    return this.dataarr.find(x => x.taskname == id);
  }
}
