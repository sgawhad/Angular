import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { TodoComponent } from './todo/todo.component';
import { DisplayComponent } from './display/display.component';
import { FormsModule } from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import { CreateComponent } from './create/create.component';


const routes: Routes =[
  {path: '', redirectTo:'/home',pathMatch :'full'},
  {path: 'home', component: HomeComponent},
  {path:'login', component:LoginComponent},
  {path: 'todo', component: TodoComponent },
  {path: 'display', component : DisplayComponent},
  {path: 'create', component : CreateComponent},
  {path: '**', redirectTo:'/home',pathMatch :'full'},

]


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    TodoComponent,
    DisplayComponent,
    CreateComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(routes), FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
