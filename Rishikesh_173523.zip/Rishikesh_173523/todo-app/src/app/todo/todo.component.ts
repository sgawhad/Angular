import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { datamodel } from '../model/datamodel';
import { ServiceService } from '../service/service.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

 

  constructor(private routes:Router) {
    
   }
   

  ngOnInit() {
  }

  addnewtask(){
    this.routes.navigate(['/create']);
  }
}
