import { Component, OnInit } from '@angular/core';
import { datamodel } from '../model/datamodel';
import { ServiceService } from '../service/service.service';
@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  dataArr: datamodel[];
  dataToEdit: datamodel;
  isEditing: boolean;
  public message = "Do you want to Delete?";
  public editmessage = "Do you want to Edit?";

  constructor(private dataService: ServiceService) {
    this.dataArr = [];
    this.dataToEdit = new datamodel()
   }

  ngOnInit() {
    this.dataArr = this.dataService.getData();
  }

  delete(index: number) {
    this.dataService.delete(index);
    alert(this.message);
  }

  edit(id: any) {
    this.isEditing = true;
    this.dataToEdit = this.dataService.edit(id);
    alert(this.editmessage);
  }

}
