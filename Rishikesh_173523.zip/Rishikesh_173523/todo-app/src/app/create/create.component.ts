import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ServiceService } from '../service/service.service';
import { datamodel } from '../model/datamodel';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {


  @Input() data: datamodel;
  @Input() isEditing: boolean;
  @Output() edited = new EventEmitter();
  
  constructor(private dataService: ServiceService) {
  this.data = new datamodel();
  this.data.taskstatus='Incomplete';
}
  ngOnInit() {
  }

  add() {
    this.dataService.add(this.data);
    this.data = new datamodel();
  }

  update()
  {
    this.isEditing = false;
    this.data = new datamodel();
    this.edited.emit();
  }

}
